 <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span> Copyright &copy; <script> document.write(new Date().getFullYear()); </script> - Développé par UPC
              STUDENTS SYSTÈME DE GESTION DE PRESENCES DES ÉTUDIANTS
            </span>
          </div>
        </div>
      </footer>